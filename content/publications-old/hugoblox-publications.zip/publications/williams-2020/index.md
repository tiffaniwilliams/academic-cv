---
title: "'Underrepresented Minority' Considered Harmful, Racist Language"
authors:
  - "me"
date: "2020-01-01"
publication_types: ["post-weblog"]
publication:
  name: "Communications of the ACM, BLOG@CACM"
  short_name: "BLOG@CACM"
  publisher: "ACM"
featured: false
links:
  - type: source
    url: "https://cacm.acm.org/blogs/blog-cacm/245710-underrepresented-minority-considered-harmful-racist-language/fulltext"
---

Cited by the Computing Research Association (CRA) as the basis for renaming its "Grad Cohort for URMD Workshop" to "The IDEALS Workshop" (Inclusion, Diversity, Equity, Accessibility, and Leadership Skills).
